from django.shortcuts import render
from django.urls import path
# Create your views here.
import pandas as pd
from django.http import HttpResponse
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression


def predict(request):
    return render(request,"predict.html")


def index(request):
    return render(request,"index.html")

def result(request):
    data=pd.read_csv('diabetes.csv')
    x=data[['Glucose','BloodPressure','Insulin','BMI','Age']]
    y=data.Outcome
    model=LogisticRegression()
    model.fit(x,y)
    val1=float(request.GET['Glucose'])
    val2=float(request.GET['Blood Pressure'])
    val3=float(request.GET['Insulin'])
    val4=float(request.GET['BMI'])
    val5=float(request.GET['Age'])
    pred=model.predict([[val1,val2,val3,val4,val5]])
    result=""
    if pred==[0]:
      result="<h1>You are not Diabetic.</h1>"
    else:
      result="<h1>You are Diabetic.</h1>"    
    return HttpResponse(result) 



